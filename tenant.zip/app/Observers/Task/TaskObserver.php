<?php

namespace App\Observers\Task;

use App\Concerns\Saas\CheckLimit;
use App\Models\Task\Task;

class TaskObserver
{
    use CheckLimit;

    /**
     * Handle the Task "creating" event.
     *
     * @param  \App\Models\Task\Task  $task
     * @return void
     */
    public function creating(Task $task)
    {
        $this->checkTaskLimit();
    }

    /**
     * Handle the Task "created" event.
     *
     * @param  \App\Models\Task\Task  $task
     * @return void
     */
    public function created(Task $task)
    {
        //
    }

    /**
     * Handle the Task "updated" event.
     *
     * @param  \App\Models\Task\Task  $task
     * @return void
     */
    public function updated(Task $task)
    {
        //
    }

    /**
     * Handle the Task "deleted" event.
     *
     * @param  \App\Models\Task\Task  $task
     * @return void
     */
    public function deleted(Task $task)
    {
        //
    }

    /**
     * Handle the Task "restored" event.
     *
     * @param  \App\Models\Task\Task  $task
     * @return void
     */
    public function restored(Task $task)
    {
        //
    }

    /**
     * Handle the Task "force deleted" event.
     *
     * @param  \App\Models\Task\Task  $task
     * @return void
     */
    public function forceDeleted(Task $task)
    {
        //
    }
}
