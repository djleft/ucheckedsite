<?php

namespace App\Console;

use Illuminate\Console\Command;
use Illuminate\Console\Events\CommandStarting;
use Illuminate\Support\Str;

class CheckCommand extends Command
{
    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle(CommandStarting $event): void
    {
        // if (Str::of($event->command)->startsWith('migrate')) {
        //     $this->output = $event->output;
        //     $this->error('You are not allowed to perform this command! Run tenant:migrate command.');
        //     die();
        // }
    }
}
