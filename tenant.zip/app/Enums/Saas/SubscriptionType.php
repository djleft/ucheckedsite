<?php

namespace App\Enums\Saas;

use App\Concerns\HasEnum;

enum SubscriptionType: string
{
    use HasEnum;

    case FREE = 'free';
    case NEW = 'new';
    case RENEW = 'renew';
    case CONTINUE = 'continue';
    case SIBLING = 'sibling';
    case UPGRADE = 'upgrade';
    case DOWNGRADE = 'downgrade';
}
