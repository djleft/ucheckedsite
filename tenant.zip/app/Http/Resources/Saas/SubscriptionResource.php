<?php

namespace App\Http\Resources\Saas;

use App\Helpers\CalHelper;
use App\Helpers\SysHelper;
use Illuminate\Http\Resources\Json\JsonResource;

class SubscriptionResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'uuid' => $this->uuid,
            'code_number' => $this->code_number ?? '-',
            'reference_number' => $this->getMeta('reference_number') ?? '-',
            'is_online' => $this->getMeta('is_online') ? true : false,
            'plan' => PlanResource::make($this->whenLoaded('plan')),
            'start_date' => CalHelper::toDate($this->start_date),
            'start_date_display' => CalHelper::showDate($this->start_date),
            'expiry_date' => CalHelper::toDate($this->expiry_date),
            'expiry_date_display' => CalHelper::showDate($this->expiry_date),
            'amount' => SysHelper::formatAmount($this->amount),
            'amount_display' => SysHelper::formatCurrency($this->amount, $this->currency),
            'created_at' => CalHelper::showDateTime($this->created_at),
            'updated_at' => CalHelper::showDateTime($this->updated_at),
        ];
    }
}
