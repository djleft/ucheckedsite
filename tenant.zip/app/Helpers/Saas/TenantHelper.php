<?php

namespace App\Helpers\Saas;

use Illuminate\Support\Arr;

class TenantHelper
{
    public static function getPlanFeature(string $feature): mixed
    {
        $features = config('saas.plan.features');

        return Arr::get($features, $feature);
    }
}
