<?php

namespace App\Providers;

use App\Concerns\ModelRelation;
use App\Contracts\Saas\PaymentGateway;
use App\Services\Saas\PaymentGateway\Razorpay;
use App\Services\Saas\PaymentGateway\Stripe;
use App\Services\Saas\PaymentGateway\Paypal;
use Illuminate\Database\Eloquent\Relations\Relation;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\ServiceProvider;
use Spatie\Activitylog\Models\Activity;

class AppServiceProvider extends ServiceProvider
{
    use ModelRelation;

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(PaymentGateway::class, function ($app) {
            if (request('gateway') === 'razorpay') {
                return $app->make(Razorpay::class);
            } elseif (request('gateway') === 'stripe') {
                return $app->make(Stripe::class);
            } elseif (request('gateway') === 'paypal') {
                return $app->make(Paypal::class);
            }
        });
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Activity::saving(function (Activity $activity) {
            $activity->properties = $activity->properties->put('ip', \Request::ip());
            $activity->properties = $activity->properties->put('user_agent', \Request::header('User-Agent'));
        });

        JsonResource::withoutWrapping();
        Validator::includeUnvalidatedArrayKeys();

        Relation::morphMap($this->relations());
    }
}
