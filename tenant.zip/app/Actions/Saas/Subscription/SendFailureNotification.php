<?php

namespace App\Actions\Saas\Subscription;

use App\Models\Saas\Subscription;
use Closure;

class SendFailureNotification
{
    public function handle(Subscription $subscription, Closure $next)
    {
        return $next($subscription);
    }
}
