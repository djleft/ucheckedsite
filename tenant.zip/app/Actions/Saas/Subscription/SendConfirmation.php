<?php

namespace App\Actions\Saas\Subscription;

use App\Models\Saas\Subscription;
use Closure;

class SendConfirmation
{
    public function handle(Subscription $subscription, Closure $next)
    {
        return $next($subscription);
    }
}
