<?php

namespace App\Actions\Saas;

use Illuminate\Http\Request;
use Illuminate\Pipeline\Pipeline;

class Install
{
    public function execute(Request $request)
    {
        app(Pipeline::class)
            ->send($request)
            ->through([
                FindInstallableTenant::class,
                CreateDatabase::class,
                MigrateAndSeedDatabase::class,
                SeedUser::class,
                Setup::class,
                SetDefaultConfig::class,
                CompleteInstallation::class,
            ])
            ->thenReturn();
    }
}
