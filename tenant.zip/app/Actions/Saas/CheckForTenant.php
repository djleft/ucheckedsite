<?php

namespace App\Actions\Saas;

use App\Enums\Saas\TenantStatus;
use App\Models\Saas\Plan;
use App\Models\Saas\Tenant;
use Closure;
use Illuminate\Support\Arr;

class CheckForTenant
{
    public function handle(Tenant $tenant, Closure $next)
    {
        $host = $_SERVER['HTTP_HOST'];

        $tld = Arr::get(parse_url(config('app.url')), 'host');
        $domainName = preg_replace('/^www\./', '', $host);
        $subdomain = current(explode('.', $domainName));

        $isSubdomain = true;
        if ($domainName != $subdomain.'.'.$tld) {
            $isSubdomain = false;
        }

        $tenant = Tenant::query()
            ->withActivePlanId()
            ->when($isSubdomain, function ($q) use ($subdomain) {
                $q->where('domain', $subdomain);
            })
            ->when(! $isSubdomain, function ($q) use ($domainName) {
                $q->whereNotNull('custom_domain')->where('custom_domain', $domainName);
            })
            ->first();

        if (! $tenant) {
            abort('398', trans('saas.errors.invalid_account'));
        }

        if (! in_array($tenant->status, TenantStatus::getKeys())) {
            abort('398', trans('saas.errors.invalid_account_status'));
        }

        if (in_array($tenant->status, [TenantStatus::SUSPENDED->value, TenantStatus::TERMINATED->value])) {
            abort('398', trans('saas.errors.account_status', ['attribute' => trans('saas.tenant.statuses.'.$tenant->status)]));
        }

        if ($tenant->is_trial && $tenant->getMeta('trial_ends_at') < today()->toDateString()) {
            $tenant->is_trial = 0;
            $tenant->save();
        }

        $isExpired = $tenant->expiry_date && $tenant->expiry_date < today()->toDateString() ? true : false;

        if (! $tenant->is_trial && ! $tenant->expiry_date) {
            $isExpired = true;
        }

        // Check limit before switching plan carefully
        if ($tenant->active_plan_id && $tenant->active_plan_id != $tenant->plan_id) {
            $tenant->plan_id = $tenant->active_plan_id;
            $tenant->save();
        }

        $plan = Plan::find($tenant->plan_id);

        if ($plan->getFeature('is_free')) {
            $isExpired = false;
        }

        if ($tenant->status == TenantStatus::RUNNING->value && $isExpired) {
            $tenant->status = TenantStatus::EXPIRED->value;
            $tenant->save();
        }

        if ($tenant->status == TenantStatus::EXPIRED->value && ! $isExpired) {
            $tenant->status = TenantStatus::RUNNING->value;
            $tenant->save();
        }

        config([
            'saas.plan' => $plan,
            'saas.tenant' => $tenant->toArray(),
            'saas.status' => ! $tenant->database ? true : false,
        ]);

        if (in_array($tenant->status, [TenantStatus::RUNNING->value, TenantStatus::EXPIRED->value])) {
            (new SwitchDatabase)->execute($tenant->database);
        }

        return $next($tenant);
    }
}
