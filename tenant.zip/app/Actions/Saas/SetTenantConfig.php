<?php

namespace App\Actions\Saas;

use App\Helpers\CalHelper;
use App\Models\Saas\Tenant;
use Closure;

class SetTenantConfig
{
    public function handle(Tenant $tenant, Closure $next)
    {
        $host = $_SERVER['HTTP_HOST'];

        config([
            'cache.prefix' => $tenant->id,
            'cache.stores.file.path' => storage_path('framework/cache/data/'.$tenant->domain),
        ]);
        app('cache')->forgetDriver(config('cache.default'));

        $expiryDate = config('saas.tenant.expiry_date');
        $expireInDays = null;
        $isExpired = false;

        if ($expiryDate && $expiryDate >= today()->toDateString()) {
            $expireInDays = CalHelper::dateDiff(today()->toDateString(), $expiryDate);
        } elseif ($expiryDate && $expiryDate < today()->toDateString()) {
            $expireInDays = -1;
        }

        if ($expiryDate && $expiryDate < today()->toDateString()) {
            $isExpired = true;
        }

        if (config('saas.plan.features.is_free', false)) {
            $isExpired = false;
        }

        $expireAlert = null;
        $alertDays = config('saas.landlord.tenant.subscription_end_alert', 7);
        $showExpiryAlert = false;

        if ($expiryDate && $expireInDays < $alertDays) {
            $showExpiryAlert = true;
        }

        $validity = [
            'is_trial' => config('saas.tenant.is_trial'),
            'expiry_date' => $expiryDate,
            'expiry_date_display' => CalHelper::showDate($expiryDate),
            'is_expired' => $isExpired,
            'redirect_on_expiration' => $isExpired ? true : false,
            'expire_in_days' => $expireInDays,
            'show_expiry_alert' => $showExpiryAlert,
            'expire_alert' => $expireAlert,
        ];

        config([
            'app.url' => 'https://'.$host,
            'session.domain' => null,
            'sanctum.stateful' => [$host],
            'saas.validity' => $validity,
        ]);

        return $next($tenant);
    }
}
