<?php

namespace App\Scopes;

trait UserScope
{
}
