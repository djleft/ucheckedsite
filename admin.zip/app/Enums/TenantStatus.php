<?php

namespace App\Enums;

use App\Concerns\HasEnum;
use App\Contracts\HasColor;

enum TenantStatus: string implements HasColor
{
    use HasEnum;

    case PENDING = 'pending';
    case RUNNING = 'running';
    case EXPIRED = 'expired';
    case SUSPENDED = 'suspended';
    case TERMINATED = 'terminated';

    public static function translation(): string
    {
        return 'tenant.statuses.';
    }

    public function color(): string
    {
        return match ($this) {
            TenantStatus::PENDING => 'info',
            TenantStatus::RUNNING => 'success',
            TenantStatus::EXPIRED => 'danger',
            TenantStatus::SUSPENDED => 'warning',
            TenantStatus::TERMINATED => 'dark-danger',
        };
    }

    public function hexColor(): string
    {
        return match ($this) {
            TenantStatus::PENDING => '#60A5FA',
            TenantStatus::RUNNING => '#34D399',
            TenantStatus::EXPIRED => '#EF4444',
            TenantStatus::SUSPENDED => '#FBBF24',
            TenantStatus::TERMINATED => '#DC2626',
        };
    }
}
