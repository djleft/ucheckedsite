<?php

namespace App\Http\Resources;

use App\Enums\PlanFrequency;
use App\Helpers\CalHelper;
use App\Helpers\SysHelper;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Arr;

class SubscriptionResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'uuid' => $this->uuid,
            'code_number' => $this->code_number,
            'tenant' => TenantResource::make($this->whenLoaded('tenant')),
            'plan' => PlanResource::make($this->whenLoaded('plan')),
            'amount' => SysHelper::formatAmount($this->amount, $this->currency),
            'amount_display' => SysHelper::formatCurrency($this->amount, $this->currency),
            'currency' => $this->currency,
            'frequency' => $this->frequency,
            'status' => $this->status ? true : false,
            'status_display' => $this->status ? trans('subscription.statuses.success') : trans('subscription.statuses.failed'),
            'frequency_detail' => PlanFrequency::getDetail($this->frequency),
            'start_date' => CalHelper::toDate($this->start_date),
            'start_date_display' => CalHelper::showDate($this->start_date),
            'expiry_date' => CalHelper::toDate($this->expiry_date),
            'expiry_date_display' => CalHelper::showDate($this->expiry_date),
            'reference_number' => $this->getMeta('reference_number') ?? '-',
            'is_online' => $this->getMeta('is_online') ? true : false,
            'name' => Arr::get($this->billing_address, 'name'),
            'email' => Arr::get($this->billing_address, 'email'),
            'address' => Arr::get($this->billing_address, 'address'),
            'created_at' => CalHelper::showDateTime($this->created_at),
            'updated_at' => CalHelper::showDateTime($this->updated_at),
        ];
    }
}
