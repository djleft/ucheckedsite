<?php

namespace App\Http\Controllers;

class HomeController extends Controller
{
    public function __invoke()
    {
        if (config('config.tenant.enable_website')) {
            return view('site.index');
        }

        return redirect()->route('app');
    }
}
