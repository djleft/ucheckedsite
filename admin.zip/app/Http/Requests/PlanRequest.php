<?php

namespace App\Http\Requests;

use App\Enums\PlanFrequency;
use App\Helpers\SysHelper;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Arr;
use Illuminate\Validation\Rule;

class PlanRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $plan = $this->route('plan');

        $rules = [
            'name' => ['required', 'min:2', 'max:100', Rule::unique('plans')->ignore($plan)],
            'code' => ['required', 'min:2', 'max:20', 'alpha', Rule::unique('plans')->ignore($plan)],
            'is_active' => 'boolean',
            'is_free' => 'boolean',
            'is_default' => 'boolean',
            'is_featured' => 'boolean',
            'is_visible' => 'boolean',
            'has_activation_charge' => 'boolean',
            'enable_tax' => 'boolean',
            'tax_type_exclusive' => 'boolean',
            'allow_using_global_mail_service' => 'boolean',
            'tax_label' => 'nullable|required_if:enable_tax,1|string|min:2|max:100',
            'tax_rate' => 'nullable|required_if:enable_tax,1|numeric|min:0|max:100',
            'max_team_limit' => 'int|min:1|max:100000',
            'team_wise_limit' => 'boolean',
            'max_task_limit' => 'int|min:1|max:100000',
            'description' => 'required|min:10|max:1000',
            'price' => 'array',
            'price.*.amount' => 'numeric|min:0|max:1000000',
            'activation_charge' => 'array',
            'activation_charge.*.amount' => 'numeric|min:0|max:1000000',
        ];

        if ($this->team_wise_limit) {
            $rules['max_employee_per_team_limit'] = 'required|min:1|max:100000';
        } else {
            $rules['max_employee_limit'] = 'required|min:1|max:100000';
        }

        return $rules;
    }

    public function withValidator($validator)
    {
        if (! $validator->passes()) {
            return;
        }

        $validator->after(function ($validator) {
            $uuid = $this->route('plan.uuid');

            $newPrice = [];
            foreach (SysHelper::getAvailableCurrencies() as $currencyName) {
                foreach (PlanFrequency::getKeys() as $frequency) {
                    $price = Arr::first($this->price, function ($item) use ($currencyName, $frequency) {
                        return Arr::get($item, 'currency') == $currencyName && Arr::get($item, 'frequency') == $frequency;
                    });

                    $amount = $this->is_free ? 0 : Arr::get($price, 'amount', 0);

                    $newPrice[$frequency][$currencyName] = $amount;
                }
            }

            $newActivationCharge = [];
            foreach (SysHelper::getAvailableCurrencies() as $currencyName) {
                $activationCharge = Arr::first($this->activation_charge, function ($item) use ($currencyName) {
                    return Arr::get($item, 'currency') == $currencyName;
                });

                $amount = $this->has_activation_charge ? Arr::get($activationCharge, 'amount', 0) : 0;

                $newActivationCharge[$currencyName] = $amount;
            }

            $this->merge([
                'price' => $newPrice,
                'activation_charge' => $newActivationCharge,
            ]);
        });
    }

    /**
     * Translate fields with user friendly name.
     *
     * @return array
     */
    public function attributes()
    {
        return [
            'name' => __('plan.props.name'),
            'code' => __('plan.props.code'),
            'description' => __('plan.props.description'),
            'price.*.amount' => __('plan.props.amount'),
            'activation_charge.*.amount' => __('plan.props.amount'),
        ];
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return [];
    }
}
