<?php

namespace App\Http\Livewire;

use App\Helpers\SysHelper;
use App\Models\Plan;
use Livewire\Component;

class Pricing extends Component
{
    public $plans;

    public $currencies;

    public $frequency;

    public $default_frequency;

    public $default_currency;

    public $default_currency_detail;

    public $columns;

    public function mount()
    {
        $this->plans = Plan::where('features->is_active', true)->where('features->is_visible', true)->get();
        $this->currencies = explode(',', config('config.system.currencies'));
        $this->frequency = 0;
        $this->default_frequency = $this->frequency ? 'annually' : 'monthly';
        $this->default_currency = config('config.system.currency');
        $this->default_currency_detail = config('config.system.currency_detail');

        if ($this->plans->count() == 1) {
            $this->columns = 'col-lg-12 col-md-12';
        } elseif ($this->plans->count() == 2) {
            $this->columns = 'col-lg-6 col-md-12';
        } elseif ($this->plans->count() == 3 || $this->plans->count() % 3 == 0) {
            $this->columns = 'col-lg-4 col-md-12';
        } elseif ($this->plans->count() == 4 || $this->plans->count() % 4 == 0) {
            $this->columns = 'col-lg-3 col-md-12';
        } else {
            $this->columns = 'col-lg-4 col-md-6';
        }
    }

    public function render()
    {
        return view('site.pricing');
    }

    public function updatedFrequency()
    {
        $this->default_frequency = $this->frequency ? 'annually' : 'monthly';
        $this->emit('frequencyChanged', $this->default_frequency);
    }

    public function updatedDefaultCurrency()
    {
        $this->default_currency_detail = SysHelper::getCurrencyDetail($this->default_currency);
        $this->emit('currencyChanged', $this->default_currency_detail);
    }
}
