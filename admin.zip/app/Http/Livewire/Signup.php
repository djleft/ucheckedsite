<?php

namespace App\Http\Livewire;

use App\Enums\TenantStatus;
use App\Models\Plan;
use App\Models\Tenant;
use App\Models\User;
use App\Notifications\ActivateAccount;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;
use Livewire\Component;

class Signup extends Component
{
    public $plans;

    public $tld;

    public $frequency;

    public $currency;

    public $email = '';

    public $name = '';

    public $contact_number = '';

    public $domain = '';

    public $plan_id = '';

    public $terms = '';

    public $response_message = '';

    public $error = false;

    public $show_resend_link = false;

    protected $listeners = ['frequencyChanged', 'currencyChanged'];

    public function mount()
    {
        $this->plans = Plan::where('features->is_active', true)->where('features->is_visible', true)->get();
        $this->tld = Arr::get(parse_url(config('app.url', $_SERVER['HTTP_HOST'])), 'host');
        $this->frequency = 'monthly';
        $this->currency = config('config.system.currency');
    }

    public function render()
    {
        return view('site.signup');
    }

    public function signup()
    {
        $this->show_resend_link = false;

        $this->validate([
            'email' => 'required|email',
            'name' => 'required|max:100',
            'contact_number' => 'required|min:5|max:20',
            'domain' => 'required|min:3|max:30|alpha_num|not_in:'.config('config.tenant.unavailable_subdomain'),
            'plan_id' => 'required|integer',
            'terms' => 'accepted',
        ]);

        $plan = Plan::whereId($this->plan_id)->where('features->is_active', true)->where('features->is_visible', true)->first();

        if (! $plan) {
            $this->error = true;
            $this->response_message = 'Invalid plan selected.';

            return;
        }

        $existingDomain = Tenant::whereDomain($this->domain)->exists();

        if ($existingDomain) {
            $this->error = true;
            $this->response_message = 'This domain is already taken.';

            return;
        }

        $isTrial = config('config.tenant.trial_period', 0) ? 1 : 0;
        $trialPeriod = $isTrial ? config('config.tenant.trial_period', 0) : 0;
        $trialEndsAt = $isTrial ? today()->addDays($trialPeriod)->format('Y-m-d') : null;

        if ($plan->getFeature('is_free')) {
            $isTrial = 0;
        }

        $tenant = Tenant::forceCreate([
            'email' => $this->email,
            'name' => $this->name,
            'domain' => $this->domain,
            'plan_id' => $this->plan_id,
            'is_trial' => $isTrial,
            'status' => TenantStatus::PENDING->value,
            'contact_number' => $this->contact_number,
        ]);

        $meta = $tenant->meta;
        $meta['activation_token'] = Str::uuid();
        $meta['currency'] = $this->currency;
        $meta['frequency'] = $this->frequency;
        $meta['trial_period'] = $trialPeriod;
        $meta['trial_ends_at'] = $trialEndsAt;
        $tenant->meta = $meta;
        $tenant->save();

        (new User())->forceFill([
            'email' => $tenant->email,
        ])->notify(new ActivateAccount($tenant));

        $this->email = '';
        $this->name = '';
        $this->contact_number = '';
        $this->domain = '';
        $this->plan_id = '';

        $this->response_message = 'Please check your email to complete the registration.';
        $this->error = false;
    }

    public function frequencyChanged($frequency)
    {
        $this->frequency = $frequency;
    }

    public function currencyChanged($currencyDetail)
    {
        $this->currency = Arr::get($currencyDetail, 'name');
    }

    public function showResendLink()
    {
        $this->show_resend_link = ! $this->show_resend_link;
    }
}
