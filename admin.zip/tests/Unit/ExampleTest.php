<?php

it('is an example', function () {
    expect(true)->toBeTrue();
});
