<?php

namespace Tests\Helpers;

class Helper
{
}
