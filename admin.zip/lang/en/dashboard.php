<?php

return [
    'dashboard' => 'Dashboard',
    'page_title' => 'Dashboard',
    'page_description' => 'Dashboard',
    'total_tenant' => 'Total Tenant',
    'total_subscription' => 'Total Subscription',
    'total_query' => 'Total Query',
];
