<?php

return [
    'general' => 'General',
    'user' => 'User',
    'todo' => 'Todo',
    'config' => 'Config',
    'role' => 'Role',
    'permission' => 'Permission',
    'locale' => 'Locale',
    'media' => 'Media',
    'option' => 'Option',
    'utility' => 'Utility',
    'modules' => 'Modules',
];
