<?php

return [
    'query' => 'Query',
    'queries' => 'Querys',
    'module_title' => 'Manage all Queries',
    'module_description' => 'Queries are the Suggestions/Feedback/Questions submitted by visitors on your website Contact form.',
    'props' => [
        'name' => 'Name',
        'email' => 'Email',
        'contact_number' => 'Contact Number',
        'subject' => 'Subject',
        'message' => 'Message',
    ],
];
