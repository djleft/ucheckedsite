<?php

return [
    'subscriber' => 'Subscriber',
    'subscribers' => 'Subscribers',
    'module_title' => 'Manage all Subscribers',
    'module_description' => 'Subscribers are the users wishing to know more about your products.',
    'props' => [
        'email' => 'Email',
        'name' => 'Name',
        'unsubscribed_at' => 'Unsubscribe At',
    ],
];
