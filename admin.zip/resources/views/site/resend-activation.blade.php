<div>
    <form method="post" role="form" wire:submit.prevent="resend" class="php-email-form">
        <div class="form-group">
            <input type="email" class="form-control" name="email" wire:model.debounce.500ms="email" placeholder="Email"/>
            <div class="validate"></div>
            @error('email') <p class="text-danger helper-message">{{ $message }}</p> @enderror
        </div>

        <div class="mb-3">
            @if ($message)
                <p class="{{ $error ? 'text-danger' : 'text-success' }} helper-message">{{$message}}</p>
            @endif
        </div>

        <div class="text-center mt-4">
            <button type="submit">Resend Activation</button>
        </div>
    </form>
</div>
