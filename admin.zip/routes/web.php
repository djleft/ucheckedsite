<?php

use App\Http\Controllers\Auth\OAuthController;
use App\Http\Controllers\Config\MailTemplateController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\SignedMediaController;
use App\Http\Controllers\SubscriptionActionController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// website route
Route::get('/', HomeController::class);
Route::view('/terms-and-conditions', 'site.terms-and-conditions')->name('site.terms');
Route::view('/privacy-policy', 'site.privacy-policy')->name('site.privacy');
Route::view('/refund-policy', 'site.refund-policy')->name('site.refund');

Route::get('/app/config/mail-template/{mail_template}', [MailTemplateController::class, 'detail'])
    ->name('config.mail-template.detail')
    ->middleware('permission:config:store');

Route::get('/media/{media}/{conversion?}', SignedMediaController::class)->name('media');

Route::get('/auth/{provider}/redirect', [OAuthController::class, 'redirect']);
Route::get('/auth/{provider}/callback', [OAuthController::class, 'callback']);

Route::get('/subscriptions/{subscription}/print', [SubscriptionActionController::class, 'print'])
    ->middleware(['web', 'auth', 'two.factor.security', 'screen.lock', 'under.maintenance', 'user.config', 'permission:subscription:read'])
    ->name('subscriptions.print');

Route::middleware('role:admin')->group(function () {
    Route::get('/cache', function () {
        \Artisan::call('optimize:clear');

        return 'Cache cleared';
    });

    Route::get('/sync-locale/{code}', function ($code) {
        \Artisan::call('sync:locale', ['--force' => true, 'code' => $code]);

        return 'Locale synced';
    });

    Route::get('/sync-permission', function () {
        \Artisan::call('sync:permission', ['--force' => true]);

        return 'Permission synced';
    });
});

// app route
Route::get('/app/{vue?}', function () {
    return view('app');
})->where('vue', '[\/\w\.-]*')->name('app');

// Fallback route
Route::fallback(function () {
    abort(404);
});
