# Tasky (SaaS) - Complete Task Management Solution

Release Date    : 28 September 2022
Author          : ScriptMint
Author Email    : hello@scriptmint.com
Skype           : ScriptMint
Website         : https://scriptmint.com
Support         : http://scriptmint.com/support
Demo            : https://tasky.in
--------------------------------------------

To read installation guidelines, please visit http://docs.scriptmint.com/task-manager

Version 1.0.0 Released
#### 28 September 2022

* SaaS Admin with Plans, Tenants, Subscriptions
* Website Layout with Pricing, Signup
* Manage Departments, Designation & Branch
* Manage Employee Records
* Track & Manage Tasks
* Task Member, Checklist, Media, Repeatation
* Manage Ledger Types, Ledgers & Transactions
* Todo, Backup & Activity Logs
* Configurations
