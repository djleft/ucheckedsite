<?php return array (
  'contact' => 'App\\Http\\Livewire\\Contact',
  'cookie-consent' => 'App\\Http\\Livewire\\CookieConsent',
  'newsletter' => 'App\\Http\\Livewire\\Newsletter',
  'pricing' => 'App\\Http\\Livewire\\Pricing',
  'resend-activation' => 'App\\Http\\Livewire\\ResendActivation',
  'signup' => 'App\\Http\\Livewire\\Signup',
);